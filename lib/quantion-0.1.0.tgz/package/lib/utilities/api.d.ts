import type { Backend } from "./backend";
import { SampleFile } from "./sampleFile";
import type { BinaryInput, IonInput, PeakOptions, BaselineOptions, NoiseLevel, Peak, Target, ChromItem, ChromPeak, Feature, FoundFeature, FindFeaturesOptions, GetFeaturesOptions, ConsensusFeature, FromTo, CentroidScan, SpectrumSummary, ScanQuery, IonImage, IonImageOptions } from "../types/types";
export type { BinaryInput, IonInput, PeakOptions, BaselineOptions, NoiseLevel, Peak, Target, ChromItem, ChromPeak, Feature, FoundFeature, FindFeaturesOptions, GetFeaturesOptions, ConsensusFeature, FromTo, CentroidScan, SpectrumSummary, ScanQuery, IonImage, IonImageOptions, };
export declare function setBackend(b: Backend): void;
export declare function setInitPromise(p: Promise<void>): void;
/**
 * Parse an mzML file buffer into a {@link SampleFile}.
 *
 * @param data - Raw mzML file bytes.
 * @returns Loaded sample file.
 */
export declare function parseMzML(data: BinaryInput): Promise<SampleFile>;
export declare function parseIon(source: IonInput, options?: {
    maxCacheSize?: number;
}): Promise<SampleFile>;
/**
 * Return the sample data as a JSON string.
 *
 * @param file - Loaded sample file.
 * @returns JSON string representation of the sample.
 */
export declare function ionToJson(file: SampleFile): string;
/**
 * Serialize a sample back to mzML format.
 *
 * @param file - Loaded sample file.
 * @returns Full mzML file content as a string.
 */
export declare function ionToMzml(file: SampleFile): string;
/**
 * Encode a sample as compressed ion binary bytes.
 *
 * @param file - Loaded sample file.
 * @param options.level - Compression level, 0 (none) to 22 (max). Default 12.
 * @param options.f32Compress - Compress intensity values to 32-bit float. Default false.
 * @returns Raw ion binary bytes.
 */
export declare function mzmlToIon(file: SampleFile, options?: {
    level?: number;
    f32Compress?: boolean;
}): Uint8Array;
/**
 * Extract an extracted ion chromatogram (EIC) for a target m/z.
 *
 * @param file - Loaded sample file.
 * @param mz - Target m/z value.
 * @param fromTo - Retention time range `{ from, to }` in minutes.
 * @param ppmTol - PPM tolerance. Default 20.
 * @param mzTol - Absolute m/z tolerance in Da. Default 0.005.
 * @returns Object with `x` (retention times) and `y` (intensities) arrays.
 */
export declare function calculateEic(file: SampleFile, mz: number, fromTo: FromTo, ppmTol?: number, mzTol?: number): Promise<{
    x: Float64Array;
    y: Float64Array;
}>;
/**
 * Detect peaks in a chromatographic trace.
 *
 * @param x - Retention time array.
 * @param y - Intensity array.
 * @param opts - Peak detection options.
 * @returns Array of detected peaks.
 */
export declare function findPeaks(x: Float64Array, y: Float64Array, opts?: PeakOptions): Peak[];
/**
 * Find a single peak near a target retention time.
 *
 * @param x - Retention time array.
 * @param y - Intensity array.
 * @param rt - Target retention time in minutes.
 * @param range - Search window half-width in minutes.
 * @param opts - Peak detection options.
 * @returns The best matching peak.
 */
export declare function getPeak(x: Float64Array, y: Float64Array, rt: number, range: number, opts?: PeakOptions): Peak;
/**
 * Estimate the noise level of an intensity array.
 *
 * @param y - Intensity array.
 * @returns The window width the estimate came from and the noise intensity.
 */
export declare function findNoiseLevel(y: Float64Array | Float32Array): NoiseLevel;
/**
 * Compute the rolling baseline of an intensity array.
 *
 * @param y - Intensity array.
 * @param options.lambda - airPLS smoothing parameter. Default auto.
 * @param options.maxIterations - Maximum airPLS iterations. Default auto.
 * @returns Baseline array, same length as `y`.
 */
export declare function calculateBaseline(y: Float64Array | ArrayLike<number>, options?: BaselineOptions): Float64Array;
/**
 * Retrieve centroid scans from a sample by retention time or precursor m/z.
 *
 * @param file - Loaded sample file.
 * @param query - Query by RT range, closest RT, m/z range, or closest m/z.
 * @param level - MS level (1 = MS1, 2 = MS2, etc.). Default 1.
 * @returns Array of scans for range queries, single scan (or null) for closest queries.
 */
export declare function getScans(file: SampleFile, query: ScanQuery, level?: number): CentroidScan[] | CentroidScan | null;
/**
 * Build a 2D ion image for a target m/z. For each spectrum, intensity in
 * `[mz - tolerance, mz + tolerance]` is summed, then the mean per
 * `position_x`/`position_y` pixel is returned as a row-major grid.
 *
 * @param file - Loaded sample file.
 * @param mz - Target m/z value.
 * @param options.tolerance - Absolute m/z half-window in Da. Default 0.125.
 * @param options.level - MS level (1 = MS1). Default 1.
 * @returns Image with `width`, `height`, `minX`, `minY`, `minZ`, `maxZ`, `data` (mean intensity), and `counts` (spectra per pixel).
 */
export declare function getIonImage(file: SampleFile, mz: number, options?: IonImageOptions): Promise<IonImage>;
/**
 * Extract and pick peaks for a list of targets using their EIC traces.
 *
 * @param file - Loaded sample file.
 * @param targets - List of targets with `id`, `rt`, `mz`, and `range`.
 * @param fromTo - Retention time range `{ from, to }` in minutes.
 * @param options - Peak detection options.
 * @param cores - Number of CPU cores to use. Default 1.
 * @returns Array of found features, one per target.
 */
export declare function getPeaksFromEic(file: SampleFile, targets: Target[], fromTo: FromTo, options?: PeakOptions, cores?: number): FoundFeature[];
/**
 * Pick peaks from pre-computed chromatogram traces.
 *
 * @param file - Loaded sample file.
 * @param items - List of chromatogram items with `idx`, `rt`, and `window`.
 * @param options - Peak detection options.
 * @param cores - Number of CPU cores to use. Default 1.
 * @returns Array of chromatogram peaks.
 */
export declare function getPeaksFromChrom(file: SampleFile, items: ChromItem[], options?: PeakOptions, cores?: number): ChromPeak[];
/**
 * Detect all chromatographic features across an m/z grid.
 * Node.js only — not available in the WASM build.
 *
 * @param file - Loaded sample file.
 * @param fromTo - Retention time range `{ from, to }` in minutes.
 * @param options - Feature detection options (eic, grid, findPeak, cores).
 * @returns Array of detected features.
 */
export declare function findFeatures(file: SampleFile, fromTo: FromTo, options?: FindFeaturesOptions): Feature[];
/**
 * Find a feature for each target using its EIC and scan data.
 *
 * @param file - Loaded sample file.
 * @param targets - List of targets with `id`, `rt`, `mz`, and `ranges`.
 * @param options - Detection options including `scanEic`, `eic`, `findPeak`, and `cores`.
 * @returns Array of found features, one per target.
 */
export declare function findFeature(file: SampleFile, targets: Target[], options?: FindFeaturesOptions & {
    scanEic?: {
        ppmTolerance?: number;
        mzTolerance?: number;
    };
    cores?: number;
}): FoundFeature[];
/**
 * Detect and group consensus features across multiple samples in a directory.
 * Node.js only — not available in the WASM build.
 *
 * @param directoryPath - Path to a directory containing ion files.
 * @param fromTo - Retention time range `{ from, to }` in minutes.
 * @param options - Feature detection and grouping options.
 * @returns Array of consensus features aligned across samples.
 */
export declare function getFeatures(directoryPath: string, fromTo: FromTo, options?: GetFeaturesOptions): ConsensusFeature[];
//# sourceMappingURL=api.d.ts.map