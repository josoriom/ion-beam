import { ContainmentCache } from "./containmentCache";
export type ByteRangeResult = {
    offset: bigint;
    length: bigint;
};
export type RemoteSource = {
    url: string;
    cache: ContainmentCache;
    total: bigint;
};
export declare const HEADER_BYTES = 1024n;
export declare function newRemoteSource(url: string): RemoteSource;
export declare function fetchRange(url: string, range: ByteRangeResult): Promise<Uint8Array>;
export declare function coalesceRanges(ranges: ByteRangeResult[], gap?: bigint): ByteRangeResult[];
export declare function prefetchRanges(source: RemoteSource, ranges: ByteRangeResult[]): Promise<void>;
export declare function fetchHeader(source: RemoteSource): Promise<Uint8Array>;
//# sourceMappingURL=remoteSource.d.ts.map