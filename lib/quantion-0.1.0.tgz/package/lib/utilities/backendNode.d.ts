import type { Backend, FileHandle } from "./backend";
import type { NoiseLevel, PeakOptions } from "../types/types";
import { ByteRangeResult } from "./remoteSource";
export declare class NodeBackend implements Backend {
    private native;
    private remote_by_handle;
    ready: boolean;
    readonly handlesAreGcFinalized = true;
    constructor(proc: NodeJS.Process);
    init(): Promise<void>;
    parseMzML(data: Uint8Array): FileHandle;
    parseBin(data: Uint8Array, maxCacheSize?: number): FileHandle;
    parseIonPath(path: string, cacheSize?: number): FileHandle;
    planOpen(header: Uint8Array): ByteRangeResult[];
    parseIonRemote(url: URL, cacheSize?: number): Promise<FileHandle>;
    parseIonBuffer(bytes: Uint8Array, cacheSize?: number): FileHandle;
    freeFile(handle: FileHandle): void;
    fileToJson(handle: FileHandle): any;
    fileToMzml(handle: FileHandle): string;
    fileToBin(handle: FileHandle, level: number, f32Compress: boolean): Uint8Array;
    calculateEic(handle: FileHandle, targetMz: number, from: number, to: number, ppmTol: number, mzTol: number): Promise<{
        x: Float64Array;
        y: Float64Array;
    }>;
    getScans(handle: FileHandle, queryType: number, a: number, b: number, level: number): any;
    getIonImage(handle: FileHandle, mz: number, tolerance: number, level: number, _onProgress?: (fetched: number, total: number, heldBytes: number) => void): any;
    findPeaks(x: Float64Array, y: Float64Array, opts: PeakOptions | undefined): any;
    getPeak(x: Float64Array, y: Float64Array, rt: number, range: number, opts: PeakOptions | undefined): any;
    findNoiseLevel(y: Float64Array | Float32Array): NoiseLevel;
    calculateBaseline(y: Float64Array, lambda: number, maxIterations: number): Float64Array;
    getPeaksFromEic(handle: FileHandle, rts: Float64Array, mzs: Float64Array, ranges: Float64Array, offsets: Uint32Array | null, lengths: Uint32Array | null, idBytes: Uint8Array | null, _idBytesLen: number, count: number, from: number, to: number, opts: PeakOptions | undefined, cores: number): any;
    getPeaksFromChrom(handle: FileHandle, indices: Uint32Array, rts: Float64Array, windows: Float64Array, _count: number, opts: PeakOptions | undefined, cores: number): any;
    findFeatures(handle: FileHandle, from: number, to: number, eicPpm: number, eicMz: number, gridStart: number, gridEnd: number, gridStep: number, opts: PeakOptions | undefined, cores: number): any;
    findFeature(handle: FileHandle, rts: Float64Array, mzs: Float64Array, ranges: Float64Array, offsets: Uint32Array | null, lengths: Uint32Array | null, idBytes: Uint8Array | null, _idBytesLen: number, count: number, cores: number, scanPpm: number, scanMz: number, eicPpm: number, eicMz: number, opts: PeakOptions | undefined): any;
    getFeatures(dirPath: string, from: number, to: number, eicPpm: number, eicMz: number, gStart: number, gEnd: number, gStep: number, groupPpm: number, groupMz: number, groupRt: number, prevalence: number, opts: PeakOptions | undefined, cores: number): any;
}
//# sourceMappingURL=backendNode.d.ts.map